-module(rabbit_xml_interceptor).

-include_lib("rabbit_common/include/rabbit.hrl").
-include_lib("rabbit_common/include/rabbit_framing.hrl").

-include_lib("config.hrl").

-behaviour(rabbit_channel_interceptor).

-export([description/0, intercept/3, applies_to/0, init/1]).

-rabbit_boot_step({?MODULE,
                   [{description, "xml interceptor"},
                    {mfa, {rabbit_registry, register,
                           [channel_interceptor,
                            <<"xml interceptor">>, ?MODULE]}},
                    {cleanup, {rabbit_registry, unregister,
                               [channel_interceptor,
                                <<"xml interceptor">>]}},
                    {requires, rabbit_registry},
                    {enables, recovery}]}).

init(Ch) ->
    create_table(),
    rabbit_channel:get_vhost(Ch).

description() ->
    [{description, <<"xml interceptor for messages">>}].

intercept(#'basic.publish'{} = Method, Content, _VHost) ->
    logger:error("INTERCEPTED: ~p", [Content]),
    case validate_msg(Content) of
        ok -> {Method, Content};
        false ->
            logger:error("DROPPING"),
            {Method, Content}
    end;

intercept(Method, Content, _VHost) ->
    {Method, Content}.

applies_to() ->
    ['basic.publish'].

%%----------------------------------------------------------------------------

%% creates an ets table (a set, really) called xsds
create_table() ->
    case lists:member(xsds, ets:all()) of
        true -> ok;
        false ->
            ets:new(xsds, [named_table, set, protected]),
            fill_table()
    end.

%% Iterates over the directories listed in the XML_FOLDERS Macro in config.hrl
fill_table() ->
    lists:foreach(
        fun(Directory) ->
            io:format("OK : Loading ~s...\n", [Directory]),
            load_files(Directory)
        end,
        ?XML_FOLDERS),
    io:format("OK : Done loading XSD files.\n").
    
%% Loads the xsd schemas contained in the files of "Directory" into the "xsds" ets table
%% Tuples stored into xsds are of form {xsd_filename_without_extension, xsd_schema}
%% Ex : The files Ncom.xsd becomes -> {Ncom, Ncom_schema}
load_files(Directory) ->
    {ok, Filenames} = file:list_dir(Directory),
    lists:foreach(
        fun(Filename) ->
            %% Loads the schema by concatenating the directory path and the filename
            %% Therefore, the leading slash of Directory is mandatory
            {ok,Schema} = xmerl_xsd:process_schema(Directory ++ Filename),
            ets:insert(xsds, {lists:nth(1,string:split(Filename,".")), Schema}),
            io:format("OK : Loaded ~s\n", [Directory ++ Filename])
        end,
        Filenames).

%% Checks whether one and one only header is named ?PROTOCOL_HEADER_NAME. If so, validate the contents of the message
validate_msg(#content{ properties=#'P_basic'{headers = Headers}, payload_fragments_rev = Content}) ->
    case lists:filter(fun({Header, _Type, _Value}) -> Header =:= list_to_binary(?PROTOCOL_HEADER_NAME) end, Headers) of
        [H] ->
            io:format("OK : Only one matching header was found.\n"),
            validate(H, Content);
        _ ->
            io:format("KO : Either too many or no matching headers were found. Dropping.\n"),
            false
    end.

%% Validates the XmlString against the schema stored in xsds
%% Returns ok if and only if
%% - The Protocol exists in the xsds table
%% - The XmlString is a well formed xml
%% - The XmlString follows the XSD structure
%% Otherwise, it returns false
validate({_Header, _Type, Protocol}, Content) ->
    %% Validation of the well formed xml string
    %% Mandatory try catch as xmerl_scan:string returns a {fatal, _} error
    %% [{quiet, true}] is used to avoid unecessary prints to stdout
    try xmerl_scan:string(binary_to_list(lists:nth(1, Content)), [{quiet, true}]) of
        {XmlElement, _} ->
            io:format("OK : The payload is a well formated XML string.\n"),
            validate_xml(Protocol, XmlElement)
    catch
        _:_ ->
            io:format("OK : Cannot parse the payload's content as XML.\n"),
            false
    end. 

%% Validates the XmlElement against the schema stored in the xsds
validate_xml(Protocol, XmlElement) ->
    case ets:lookup(xsds, binary_to_list(Protocol)) of
        [{_, Value}] -> 
            io:format("OK : The protocol is supported by the loaded XSD files.\n"),
            case xmerl_xsd:validate(XmlElement, Value) of
                {error, _} ->
                    io:format("KO : The XSD cannot validate the XML.\n"),
                    false;
                {_, _} ->
                    io:format("OK : The XSD validated the XML.\n"),
                    ok
            end;
        [] ->
            io:format("KO : The protocol \"~s\" is not supported.\n", [Protocol]),
            false
    end.