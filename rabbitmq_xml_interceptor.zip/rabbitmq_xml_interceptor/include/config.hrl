%%% Configuration file.
%%% WARNING : The trailing slash of the folders are mandatory !
-define(XML_FOLDERS, [
    
]).

-define(PROTOCOL_HEADER_NAME,"").